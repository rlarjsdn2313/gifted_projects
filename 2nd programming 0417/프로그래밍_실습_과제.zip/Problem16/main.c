#include <stdio.h>

void main(void) {
    for (int i=0; i<3; i++) {
        for (int i2=0; i2<6; i2++) {
            printf("*");
        }
        printf("\n");
    }
}