#include <stdio.h>

void main(void) {
    for (int i=0; i < 6; i++) {
        printf("*");
    }
    printf("\n");
}